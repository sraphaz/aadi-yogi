Darshan - Sky-Forge session package
====================================

Contents
--------
session/    Sky-Forge session artifacts. Copy this folder to
            .sky/sessions/darshan/ inside a sky-forge checkout, then:
              ./scripts/sky/sky.ps1 status  -Slug darshan
              ./scripts/sky/sky.ps1 export  -Slug darshan -Completeness partial
narrative/  The design documents behind the artifacts (concept, spec,
            library depth design, becoming path, sky map, house of nature,
            reuse map).

Source repository: https://github.com/sraphaz/aadi-yogi
